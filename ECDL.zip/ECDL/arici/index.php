<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="ie=edge">
        <title>Hedgehog Quiz</title>
        <link rel="stylesheet" type="text/css" href="css/index.css" />
        <link rel="shortcut icon" type="image/png" href="image/logo.png" />
        <link rel="icon" type="image/png" href="image/arici.png" sizes="16x16">        
        <style type="text/css">
            .main{
                width: 100%;
                height: 100vh;
                background: url(image/book.png) ;
                background-position: center center;
                background-repeat: no-repeat;
                background-attachment: fixed;
                background-size: cover;
            }
        </style>
    </head>
    <body>
        <center>
        <div class="main">
            <div class="intro">
                <h1> hedgehoquiz </h1>
                <a href="login.php" class="btn"> login </a> &emsp;
                <a href="register.php" class="btn"> register </a>
                <p>Ariciul este un mamifer mic care aparține ordinului insectivorelor, având o lungime a corpului de până la 33 de cm. Greutatea variază de la 800-1200g, în dependență de specie. Ei au membre mici și puternice, membrele posterioare fiind puțin mai mari și musculoase ca cele anterioare. Membrele au câte 5 degete, unde primul și ultimul deget sunt mai mici în comparație cu celelalte degete și nu au gheare. Au niște ochi mici și o ureche externă slab dezvoltată. Au un bot mic și ascuțit, cu o acuitate olfactivă foarte dezvoltată. Partea dorsală și laterală a corpului este acoperită cu niște ace lungi și ascuțite, alcătuite din cheratină și având o lungime de 10-20 de mm. Pe corpul unui arici pot fi până la 15.000 de astfel de ace. Se deosebesc, în Europa, după ariile de răspândire predominantă, în est Erinaceus concolor (cel întâlnit și în România), iar în vest Erinaceus europeus. Poate mușca atunci când se simte în pericol.</p>
                <h2> Succes! </h2>
            </div>
        </div>
        </center>
    </body>
</html>